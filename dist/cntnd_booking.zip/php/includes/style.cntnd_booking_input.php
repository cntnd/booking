<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_booking/css/cntnd_booking.css') ?>
</style>
