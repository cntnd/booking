<?php
// cntnd_booking_output

// assert framework initialization
defined('CON_FRAMEWORK') || die('Illegal call: Missing framework initialization - request aborted.');

// editmode
$editmode = cRegistry::isBackendEditMode();
$smarty = cSmartyFrontend::getInstance();
$mailer = new cMailer();

$dat_von = "CMS_VALUE[1]";
$dat_bis = "CMS_VALUE[2]";
$time_von = "CMS_VALUE[3]";
$time_bis = "CMS_VALUE[4]";
$interval = "CMS_VALUE[5]";

$mailto = "CMS_VALUE[6]";

$anzeige = "CMS_VALUE[7]";

$sperrtage[1] = (empty("CMS_VALUE[11]")) ? false : true;
$sperrtage[2] = (empty("CMS_VALUE[12]")) ? false : true;
$sperrtage[3] = (empty("CMS_VALUE[13]")) ? false : true;
$sperrtage[4] = (empty("CMS_VALUE[14]")) ? false : true;
$sperrtage[5] = (empty("CMS_VALUE[15]")) ? false : true;
$sperrtage[6] = (empty("CMS_VALUE[16]")) ? false : true;
$sperrtage[0] = (empty("CMS_VALUE[10]")) ? false : true;

//$mailto   = "info@schuepfenried.ch";
//$mailto="thomas@dasco.li";

switch ($interval){
    case '30':
            $interval_check = "1800";
            break;
    case '60':
            $interval_check = "3600";
            break;
    case '120':
            $interval_check = "7200";
            break;
}
switch ($anzeige){
    case '1week':
            $anzeige_check = "+1 Week";
            break;
    case '2week':
            $anzeige_check = "+2 Week";
            break;
    case '3week':
            $anzeige_check = "+3 Week";
            break;
    case '4week':
            $anzeige_check = "+4 Week";
            break;
}

$wtag[0] = "So.";
$wtag[1] = "Mo.";
$wtag[2] = "Di.";
$wtag[3] = "Mi.";
$wtag[4] = "Do.";
$wtag[5] = "Fr.";
$wtag[6] = "Sa.";

$error=false;

if (empty($dat_von) OR empty($dat_bis) OR empty($time_von) OR empty($time_bis) OR empty($interval)){
    echo "Bitte konfigurieren!";
}
else {
    if (!$editmode){
        // PUBLIC
        if (!empty($_POST['action']) AND count($_POST['time'])>0 AND empty($_COOKIE['refresh'])){
            setcookie("refresh", "refresh", time()+60);

            //var_dump($_POST['time']);
            $datum = date("Y-m-d",$_POST['time'][0]);
            $dat_email=date("d.m.Y",$_POST['time'][0]);
            $time_von = date("H:i",$_POST['time'][0]);
            $time_bis = date("H:i",end($_POST['time'])+3600); // eine stunde dazu addieren, da immer nur "von" zeiten vom system kommen.

            $sql = "INSERT INTO cntnd_reservation
                                (name, adresse, plz_ort, email, telefon, personen, bemerkungen, status, datum, time_von, time_bis, mut_dat) VALUES
                                ('".$_POST['name']."','".$_POST['adresse']."','".$_POST['plz_ort']."','".$_POST['email']."','".$_POST['telefon']."','".$_POST['personen']."','".$_POST['bemerkungen']."','blocked','".$datum."','".$time_von."','".$time_bis."',NOW())";
            //echo $sql;
            $db->query($sql);
            // mail
            // use template to display email
            $smarty->assign('dat_email', $dat_email);
            $smarty->assign('name', $_POST['name']);
            $smarty->assign('adresse', $_POST['adresse']);
            $smarty->assign('plz_ort', $_POST['plz_ort']);
            $smarty->assign('telefon', $_POST['telefon']);
            $smarty->assign('bemerkungen', $_POST['bemerkungen']);
            $smarty->assign('email', $_POST['email']);
            $smarty->assign('personen', $_POST['personen']);
            $smarty->assign('time_von', $time_von);
            $smarty->assign('time_bis', $time_bis);
            $message = $smarty->fetch('reservation-mail.html');

			// Create a message
			$message = Swift_Message::newInstance('fcbreitenrain.ch - Ihre Reservation')
			  ->setFrom(array('noreply@fcbreitenrain.ch' => 'fcbreitenrain.ch - Reservation'))
			  ->setTo($_POST['email'])
			  ->setBody($message, 'text/html');

			// Send the message
			$result = $mailer->send($message);
            $reserved=true;
        }
        else if (!empty($_POST['action']) AND count($_POST['time'])==0) {
            $error=true;
        }
    }
    else {
        // ADMIN MODUS
        if (!empty($_POST['action']) AND !empty($_POST['res_id'])){
            $sql = "SELECT * FROM cntnd_reservation WHERE id='".$_POST['res_id']."'";
            $db->query($sql);
            $rows = $db->num_rows();
            while ($db->next_record()) {
                $name=$db->f('name');
                $adresse=$db->f('adresse');
                $plz_ort=$db->f('plz_ort');
                $telefon=$db->f('telefon');
                $bemerkungen=$db->f('bemerkungen');
                $email=$db->f('email');
                $personen=$db->f('personen');
                $time_von=$db->f('time_von');
                $time_bis=$db->f('time_bis');
                $empfaenger=$db->f('email');
                $datum = date("d.m.Y", strtotime($db->f('datum')));
                $datum_orig=$db->f('datum');
            }

            if ($_POST['action']=="reserve"){
                $sql = "UPDATE cntnd_reservation SET status = 'reserved' WHERE id = '".$_POST['res_id']."'";
                $db->query($sql);
                // mail
                if ($_POST['send_email']=="yes"){
                    echo '<span class="res_reserved">E-Mail versendet.</span>';

                    // use template to display email
                    $smarty->assign('message', $_POST['bemerkungen']);
                    $smarty->assign('name', $name);
                    $smarty->assign('adresse', $adresse);
                    $smarty->assign('plz_ort', $plz_ort);
                    $smarty->assign('telefon', $telefon);
                    $smarty->assign('bemerkungen', $bemerkungen);
                    $smarty->assign('email', $email);
                    $smarty->assign('personen', $personen);
                    $smarty->assign('time_von', $time_von);
                    $smarty->assign('time_bis', $time_bis);
                    $smarty->assign('empfaenger', $empfaenger);
                    $smarty->assign('datum', $datum);
                    $smarty->assign('datum_orig', $datum_orig);
                    $message = $smarty->fetch('reservation-definitiv-email.html');

                    // Create a message
					$message = Swift_Message::newInstance('fcbreitenrain.ch - Definitive bestätigung Ihrer Reservation')
					  ->setFrom(array('noreply@fcbreitenrain.ch' => 'fcbreitenrain.ch - Reservation'))
					  ->setTo($empfaenger)
					  ->setBody($message, 'text/html');

					// Send the message
					$result = $mailer->send($message);
                }
            }
            else {
                $sql = "DELETE FROM cntnd_reservation WHERE id = '".$_POST['res_id']."'";
                $db->query($sql);
                // mail
                if ($_POST['send_email']=="yes"){
                    echo '<span class="res_reserved">E-Mail versendet.</span>';
                    // use template to display email
                    $smarty->assign('message', $_POST['bemerkungen']);
                    $smarty->assign('name', $name);
                    $smarty->assign('adresse', $adresse);
                    $smarty->assign('plz_ort', $plz_ort);
                    $smarty->assign('telefon', $telefon);
                    $smarty->assign('bemerkungen', $bemerkungen);
                    $smarty->assign('email', $email);
                    $smarty->assign('personen', $personen);
                    $smarty->assign('time_von', $time_von);
                    $smarty->assign('time_bis', $time_bis);
                    $smarty->assign('empfaenger', $empfaenger);
                    $smarty->assign('datum', $datum);
                    $smarty->assign('datum_orig', $datum_orig);
                    $message = $smarty->fetch('reservation-abgelehnt-mail.html');

                                        // Create a message
					$message = Swift_Message::newInstance('fcbreitenrain.ch - Ihre Reservation wurde gelöscht')
					  ->setFrom(array('noreply@fcbreitenrain.ch' => 'fcbreitenrain.ch - Reservation'))
					  ->setTo($empfaenger)
					  ->setBody($message, 'text/html');

					// Send the message
					$result = $mailer->send($message);
                }
            }

        }
    }

    $dat_von = "CMS_VALUE[1]";
    $dat_bis = "CMS_VALUE[2]";
    $time_von = "CMS_VALUE[3]";
    $time_bis = "CMS_VALUE[4]";

    if (!$editmode){
            // PUBLIC
        $sql = "SELECT * FROM cntnd_reservation WHERE datum between '".date("Y-m-d",strtotime($dat_von))."' AND '".date("Y-m-d",strtotime($dat_bis))."' ORDER BY datum, time_von";
    }
    else {
            // ADMIN MODUS
        $sql = "SELECT * FROM cntnd_reservation WHERE datum >= '".date("Y-m-d")."' ORDER BY datum, time_von";
    }
    //echo '<!--'.$sql.' -->';
    // RESET
    $last_datum="";
    $data_detail="";
    $data_row="";
    $data_db="";
    // END RESET
    $db->query($sql);
    $rows = $db->num_rows();
    while ($db->next_record()) {
        if (!empty($last_datum) AND $last_datum!=$db->f('datum')){
            unset($data_row);
        }
        $last_datum=$db->f('datum');
        $data_detail = array("id"=>$db->f('id'),"name"=>$db->f('name'),"adresse"=>$db->f('adresse'),"status"=>$db->f('status'),"plz_ort"=>$db->f('plz_ort'),"email"=>$db->f('email'),"telefon"=>$db->f('telefon'),"personen"=>$db->f('personen'),"bemerkungen"=>$db->f('bemerkungen'),"time_von"=>$db->f('time_von'),"time_bis"=>$db->f('time_bis'));
        $data_row[$db->f('time_von')]=$data_detail;
        $data_db[date("d.m.Y",strtotime($db->f('datum')))]=$data_row;
    }

    // reserved = reserviert (checkbox=disabled) / blocked = blockiert muss noch reserviert werden
    // formular: name/vorname*, adresse, plz/ort, email*, telefon, bemerkungen (spam schutz)
    // plausi: alle * und prüfen ob eine checkbox ausgewählt (topjobs.li) => jquery
    // grafische darstellung ?!

    if (!$editmode) {
        echo '
          <script>
          $(document).ready(function(){
            $("#res").validate();
          });

          var last_check=0;
          function show(id,count){
                // checkboxen anzeigen/ausblenden
                var i=0;
                for (i=0;i<=count;i++) {
                   if (last_check>0){
                       // letzte zeile ausblenden
                       document.getElementById(last_check+"-"+i).style.display="none";
                   }
                   document.getElementById(id+"-"+i).style.display="block";
                }
                last_check = id;
          }
          </script>
        ';
        echo '<form method="post" class="cmxform" id="res" name="res" action="front_content.php?idart='.$idart.'">';
        echo '<p class="untertitel">'.strip_tags("CMS_HTMLHEAD[2]")."</p>";
        echo "CMS_HTML[2]";
        // tabelle mit allen zeiten und tagen
        echo '<table rules="all" class="res" border="1">';
        echo '<thead><tr>';
        echo '<th>Datum</th>';

        $min=$time_von;
        while($min<=$time_bis){
            $time = date("H:i", mktime(0, $min, 0, 1, 1, 2000));
            $timebis = date("H:i", mktime(0, $min+60, 0, 1, 1, 2000));
            echo '<th>'.$time.' bis '.$timebis.'</th>'."\n";
            $min=$min+$interval;
        }
        echo '</tr></thead>';

        if (date('Ymd',strtotime($dat_von))<date('Ymd')){
            $dat_von = date('d.m.Y');
        }

        $dat_d     = date('d',strtotime($dat_von));
        $dat_von_m = date('m',strtotime($dat_von));
        $dat_von_Y = date('Y',strtotime($dat_von));
        $dat_bis_check=date('Ymd',strtotime($dat_bis));

        $count = ($time_bis-$time_von)/$interval;

        echo '<tbody>';

		// anzeige
		$dat_anzeige=date('Ymd', strtotime($anzeige_check));
		if (date('Ymd')<date('Ymd',strtotime($dat_von))){
			$dat_anzeige=date('Ymd', strtotime($dat_von.' '.$anzeige_check));
    }
		if ($dat_anzeige>$dat_bis_check || $anzeige=='all'){
			$dat_anzeige=$dat_bis_check;
		}

        while($dat<$dat_bis_check){

            $dat = date("Ymd", mktime(0, 0, 0, $dat_von_m, $dat_d, $dat_von_Y));
            $date= date("d.m.Y", mktime(0, 0, 0, $dat_von_m, $dat_d, $dat_von_Y));
            $tag=date("w", mktime(0, 0, 0, $dat_von_m, $dat_d, $dat_von_Y));
            $kwClass='';
            if ($kw!==date('W',mktime(0, 0, 0, $dat_von_m, $dat_d, $dat_von_Y)) && !empty($kw)){
              $kwClass=' kw-dat';
            }
            $kw=date('W',mktime(0, 0, 0, $dat_von_m, $dat_d, $dat_von_Y));

			// wenn nicht sperrtage, dann anzeigen
			if (!$sperrtage[$tag]){
				$hide = '';
				if ($dat>$dat_anzeige){
					$hide='hide-dat hide';
				}
        $evenClass='';
        $even=($kw % 2 == 0);
        if ($even){
          $evenClass=' even-dat';
        }
				echo '<tr class="'.$hide.$evenClass.$kwClass.'">';
				echo '<td align="right"><b><nobr><a href="javascript:show('.$dat.','.$count.');">'.$wtag[$tag].' '.$date.'</a></nobr></b></td>';

				$min=$time_von;
				$class="free";
				$i=0;
				while($min<=$time_bis){
					$timestamp = mktime(0, $min, 0, $dat_von_m, $dat_d, $dat_von_Y);
					$time      = date("H:i:s", $timestamp);

					if (@array_key_exists($date,$data_db)){
						$data = $data_db[$date];

						if (array_key_exists($time,$data)){
							$class = $data[$time]['status'];
							if (!empty($class) AND !$editmode){
								$disabled = "disabled";
							}
							 // jetzt muss beim bis eine stunde abgezogen werden, da immer nur die "von" zeit angezeigt wird. bsp: 8:00 bis 9:00 ist ein feld! jedoch gibt es ein "von 8:00" und ein "von 9:00" feld
							list($time_bis_H, $time_bis_I) = explode(":", $data[$time]['time_bis']);
							// INTERVAL CHECK weil nicht alle Felder eine Stunde (3600) haben!!!!
							$check_time_bis = date("H:i:s",mktime($time_bis_H, $time_bis_I, 0, 1, 1, 2000)-$interval_check);
						}
					}

					echo '<td align="center" class="'.$class.'"><input type="checkbox" class="res_checkbox" id="'.$dat.'-'.$i.'" name="time[]" value="'.$timestamp.'" '.$checked.' '.$disabled.' /></td>'."\n";
					$min=$min+$interval;

					if ($time==$check_time_bis ){
						$class='free';
						$disabled='';
					}
					$i++;
				}
				echo "</tr>";
			}
            $dat_d++;
        }
        echo '</tbody>';
        echo '</table>';
        //mehr/Wengier
        echo '<p>';
        echo '<span class="more-less">Mehr Anzeigen</span>';
        echo '<span class="more-less hide">Weniger Anzeigen</span>';
        echo '</p>';


        // formular etc...
        if ($error){ echo '<span class="res_error">Es gab ein Fehler, bitte wählen Sie mindestens einen Zeitraum aus.</span>'; }
    	  if ($reserved){ echo '<span class="res_reserved">Die Reservation wurde getätigt, sie erhalten in kürze eine Bestätigung per E-Mail.</span>';}

        // use template to display formular
        $smarty->display('reservation-formular.html');

        echo '<input type="submit" value="Reservieren" />';
        echo '<input type="hidden" name="action" value="do_it" id="action" />';
        echo '</form>';
    }
    else {
        // ADMIN MODUS
        echo '
          <script>

          function doRes(status, msg){
              document.getElementById("action").value=status;
              return confirm(msg)
          }

          </script>
        ';
        // admin modus
        echo '<p>Reservationssystem:<div style="border: 1px dashed silver;">';
        echo 'Untertitel:<p class="untertitel">'."CMS_HTMLHEAD[2]"."</p>";
        echo 'Text:<p>'."CMS_HTML[2]"."</p>";
        echo "Admin-Modus<br />";
        if (is_array($data_db)){
            echo '<form action="" method="post" id="res_admin" name="res_admin">';
            foreach ($data_db as $date => $rows){
                echo '<b>'.$date.'</b>';
                echo '<ul width="auto">';
                foreach ($rows as $time_von_admin => $details){
                    echo '<li class="'.$details['status'].'"><input type="radio" name="res_id" value="'.$details['id'].'" /><b>'.$time_von_admin.'</b> bis '.$details['time_bis'].'&nbsp;-&nbsp;Personen: '.$details['personen'].'<br />';
                    echo "&nbsp;".$details['name']."<br />&nbsp;".$details['adresse'].",&nbsp;".$details['plz_ort']."<br />&nbsp;".$details['email']."<br />&nbsp;".$details['telefon']."<br />&nbsp;".$details['bemerkungen']."</li>";
                }
                echo '</ul>';
            }
            // admin modus
            // javascript: new document(popup/layer) link der aufgeht und php script ausführt (via jquery?!)
            echo '<b>Ausgewählte Zeiten:</b><br />';
            echo 'Bemerkungen: <textarea name="bemerkungen"></textarea><p />';
            echo 'Aktion: <input type="submit" onclick="return doRes(\'reserve\',\'Ausgewählte Zeiten bestätigen und definitiv Reservieren?\')" value="Reservieren" />&nbsp;<input type="submit" onclick="return doRes(\'delete\',\'Ausgewählte Zeiten definitiv Löschen?\');" value="Löschen" /><br />';
            echo 'E-Mail: <input type="checkbox" id="send_email" name="send_email" value="yes" checked /> Ja, senden<br />';
            echo '<input type="hidden" name="action" value="do_it" id="action" />';
            echo '</form>';
        }
        else {
            echo "<b>keine Reservationen oder Buchungen in diesem Zeitraum</b>";
        }
        echo '</div>';
    }
}
?>
