?><?php
// cntnd_booking_input

// input/vars
$interval = "CMS_VALUE[5]";
switch ($interval){
    case '30':
            $check_30 = 'selected="selected"';
            break;
    case '60':
            $check_60 = 'selected="selected"';
            break;
    case '120':
            $check_120 = 'selected="selected"';
            break;
}

if (empty($interval)){
    $time_bis = 'disabled="disabled"';
    $time_msg = "<b>(zuerst Intervall und Tageszeit-Von auswählen)</b>";
}

// other/vars

// includes
cInclude('module', 'includes/script.cntnd_booking_input.php');
cInclude('module', 'includes/style.cntnd_booking_input.php');
?>
<div class="form-vertical">
  <div class="form-group">
    <label for="daterange"><?= mi18n("DATERANGE") ?></label>
    <input id="daterange" class="cntnd_booking_daterange" type="text" name="CMS_VAR[1]" value="CMS_VALUE[1]" />
  </div>
  
  <div class="form-group">
    <span><?= mi18n("BLOCKED_DAYS") ?></span>
    <div class="form-check form-check-inline">
      <input id="blocked_day_mo" class="form-check-input" type="checkbox" name="CMS_VAR[11]" value="true" <?php if("CMS_VALUE[11]"=='true'){ echo 'checked'; } ?> />
      <label for="blocked_day_mo" class="form-check-label">Mo.</label>
    </div>
    <div class="form-check form-check-inline">
      <input id="blocked_day_di" class="form-check-input" type="checkbox" name="CMS_VAR[12]" value="true" <?php if("CMS_VALUE[12]"=='true'){ echo 'checked'; } ?> />
      <label for="blocked_day_di" class="form-check-label">Di.</label>
    </div>
    <div class="form-check form-check-inline">
      <input id="blocked_day_mi" class="form-check-input" type="checkbox" name="CMS_VAR[13]" value="true" <?php if("CMS_VALUE[13]"=='true'){ echo 'checked'; } ?> />
      <label for="blocked_day_mi" class="form-check-label">Mi.</label>
    </div>
    <div class="form-check form-check-inline">
      <input id="blocked_day_do" class="form-check-input" type="checkbox" name="CMS_VAR[14]" value="true" <?php if("CMS_VALUE[14]"=='true'){ echo 'checked'; } ?> />
      <label for="blocked_day_do" class="form-check-label">Do.</label>
    </div>
    <div class="form-check form-check-inline">
      <input id="blocked_day_fr" class="form-check-input" type="checkbox" name="CMS_VAR[15]" value="true" <?php if("CMS_VALUE[15]"=='true'){ echo 'checked'; } ?> />
      <label for="blocked_day_fr" class="form-check-label">Fr.</label>
    </div>
    <div class="form-check form-check-inline">
      <input id="blocked_day_sa" class="form-check-input" type="checkbox" name="CMS_VAR[16]" value="true" <?php if("CMS_VALUE[16]"=='true'){ echo 'checked'; } ?> />
      <label for="blocked_day_sa" class="form-check-label">Sa.</label>
    </div>
    <div class="form-check form-check-inline">
      <input id="blocked_day_so" class="form-check-input" type="checkbox" name="CMS_VAR[10]" value="true" <?php if("CMS_VALUE[10]"=='true'){ echo 'checked'; } ?> />
      <label for="blocked_day_so" class="form-check-label">So.</label>
    </div>
  </div>
</div>

<b>Konfiguration Reservationssystem</b><p />
<table><tr>

<td>Zeitraum:</td>
<td>bis <input type="text" name="CMS_VAR[2]" value="CMS_VALUE[2]" /></td>

</tr><tr>

<td>Intervall:</td>
<td colspan="2">
    <select name="CMS_VAR[5]" size="1">
        <option value=""> - </option>
        <option value="30" <?= $check_30 ?>> 30 Minuten</option>
        <option value="60" <?= $check_60 ?>> 1 Stunde</option>
        <option value="120" <?= $check_120 ?>> 2 Stunden</option>
    </select>
</td>

</tr><tr>

<td>Tageszeit <?= $time_msg ?>:</td>
<td>
    von <select name="CMS_VAR[3]" size="1">
        <?php
            $von = "CMS_VALUE[3]";

            for ($i=0;$i<48;$i++){
                $selected = "";
                $time = date("H:i", mktime(0, $min, 0, 1, 1, 2000));
                if ($min==$von){
                    $selected = 'selected="selected"';
                }
                echo '<option value="'.$min.'" '.$selected.'> '.$time.'</option>';
                $min=$min+30;
            }
        ?>
        </select>
</td>
<td>
        bis <select name="CMS_VAR[4]" size="1" <?= $time_bis ?>>
        <?php
            $bis = "CMS_VALUE[4]";
            if (!empty($von)){
                $min = $von;
                while($min<1440){
                    $selected = "";
                    $time = date("H:i", mktime(0, $min, 0, 1, 1, 2000)+3600);
                    if ($min==$bis){
                        $selected = 'selected="selected"';
                    }
                    echo '<option value="'.$min.'" '.$selected.'> '.$time.'</option>';
                    $min=$min+$interval;
                }
            }
        ?>
        </select>
</td>

</tr><tr>

<td>Anzeige Zeitraum:</td>
<td colspan="2">
    von <select name="CMS_VAR[7]" size="1">
	<option value="all">- ganzer Zeitraum anzeigen -</option>
        <?php
            $blocked = "CMS_VALUE[7]";
            for ($i=1;$i<5;$i++){
                $selected = "";
				$val=$i."week";
                if ($val==$blocked){
                    $selected = 'selected="selected"';
                }
                echo '<option value="'.$val.'" '.$selected.'> '.$i.' Woche(n) </option>';
            }
        ?>
        </select>

</td>

</tr><tr>
<td>E-Mail:</td>
<td colspan="2">
	<?php
		$mailto = "CMS_VALUE[9]";
	?>
    <input type="text" name="CMS_VAR[9]" value="<?php echo $mailto; ?>" />
</td>

</tr></table>
